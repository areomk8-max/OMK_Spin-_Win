# OMK Spin & Win — Android Studio project

AdMob IDs inserted from the account screenshot:
- App ID: ca-app-pub-9302715256217991~2420950984
- Banner Ad Unit ID: ca-app-pub-9302715256217991/7235787258

Open the `SpinWinAndroid` folder in Android Studio and allow Gradle sync.
This is source code, not a compiled or signed APK.

Important:
- Use Google's test ad IDs or register your device as a test device while developing. Do not click your own live ads.
- Newly created ad units can take time to begin serving ads; account/app review may also limit serving.
- Add a privacy policy and complete applicable consent, Data safety, and Play Store declarations before release.
- The game currently awards virtual coins only; coins have no cash value or cash-out feature.
